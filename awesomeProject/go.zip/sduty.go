package main

import (
	"fmt"
)


func main() {
	num_S := []int{1,2, 3, 4}
	var num_Count  int
	for i := range(num_S){
		for y := range(num_S){
			for z := range(num_S){
				if (i!=z) && (i!=y) && (y!=z){
					fmt.Println(i+1,y+1,z+1)
					num_Count ++
				}
			}
		}
	}
	fmt.Println("总数为：", num_Count)
}